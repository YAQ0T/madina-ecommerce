// server/routes/homeCollections.js
const express = require("express");
const router = express.Router();
const HomeCollections = require("../models/HomeCollections");
const Product = require("../models/Product");
const { verifyToken, isAdmin } = require("../middleware/authMiddleware");

// ====== Admin: حفظ القوائم ======
router.put("/", verifyToken, isAdmin, async (req, res) => {
  try {
    const { recommended = [], newArrivals = [] } = req.body || {};

    // (اختياري) تصفية المعرّفات للتأكد من وجود المنتجات
    const recIds = Array.isArray(recommended) ? recommended : [];
    const newIds = Array.isArray(newArrivals) ? newArrivals : [];

    const existingRec = await Product.find(
      { _id: { $in: recIds } },
      { _id: 1 }
    ).lean();
    const existingNew = await Product.find(
      { _id: { $in: newIds } },
      { _id: 1 }
    ).lean();

    const onlyValidRec = existingRec.map((d) => d._id);
    const onlyValidNew = existingNew.map((d) => d._id);

    const doc = await HomeCollections.findOneAndUpdate(
      {},
      {
        $set: {
          recommended: onlyValidRec,
          newArrivals: onlyValidNew,
        },
      },
      { upsert: true, new: true }
    );

    res.json(doc);
  } catch (err) {
    console.error("PUT /api/home-collections error:", err);
    res.status(500).json({ message: "خطأ في الخادم" });
  }
});

// ====== Get: كلا القائمتين ======
router.get("/", async (_req, res) => {
  try {
    const doc = await HomeCollections.findOne({})
      .populate("recommended")
      .populate("newArrivals");
    res.json(doc || { recommended: [], newArrivals: [] });
  } catch (err) {
    console.error("GET /api/home-collections error:", err);
    res.status(500).json({ message: "خطأ في الخادم" });
  }
});

// ====== Get: الموصى بها فقط ======
router.get("/recommended", async (_req, res) => {
  try {
    const doc = await HomeCollections.findOne({});
    if (!doc) return res.json([]);
    const populated = await HomeCollections.findById(doc._id).populate(
      "recommended"
    );
    const list = (populated?.recommended || []).map((p) =>
      p.toObject ? p.toObject() : p
    );
    res.json(list);
  } catch (err) {
    console.error("GET /api/home-collections/recommended error:", err);
    res.status(500).json({ message: "خطأ في الخادم" });
  }
});

// ====== Get: الجديد فقط ======
router.get("/new", async (_req, res) => {
  try {
    const doc = await HomeCollections.findOne({});
    if (!doc) return res.json([]);
    const populated = await HomeCollections.findById(doc._id).populate(
      "newArrivals"
    );
    const list = (populated?.newArrivals || []).map((p) =>
      p.toObject ? p.toObject() : p
    );
    res.json(list);
  } catch (err) {
    console.error("GET /api/home-collections/new error:", err);
    res.status(500).json({ message: "خطأ في الخادم" });
  }
});

module.exports = router;
