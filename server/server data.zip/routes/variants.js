const express = require("express");
const router = express.Router();

const Variant = require("../models/Variant");
const { verifyToken, isAdmin } = require("../middleware/authMiddleware");

// دوال مساعدة
function isDiscountActive(discount = {}) {
  if (!discount || !discount.value) return false;
  const now = new Date();
  if (discount.startAt && now < discount.startAt) return false;
  if (discount.endAt && now > discount.endAt) return false;
  return true;
}
function computeFinalAmount(price = {}) {
  const amount = typeof price.amount === "number" ? price.amount : 0;
  const compareAt =
    typeof price.compareAt === "number" ? price.compareAt : null;
  return { amount, compareAt };
}

/* ... باقي الراوتات كما هي ... */

// خصم المخزون «يجب أن يكون أدمن/داخلي فقط»
router.post("/:id/decrement-stock", verifyToken, isAdmin, async (req, res) => {
  try {
    const qty = Math.max(1, parseInt(req.body?.qty, 10) || 1);
    const upd = await Variant.updateOne(
      { _id: req.params.id, "stock.inStock": { $gte: qty } },
      { $inc: { "stock.inStock": -qty } }
    );
    if (!upd.modifiedCount) {
      return res.status(409).json({ error: "الكمية غير كافية" });
    }
    return res.json({ ok: true });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

module.exports = router;
